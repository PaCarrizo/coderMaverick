from django.apps import AppConfig


class AppmaverickConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'appMaverick'
